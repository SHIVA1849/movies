import React from 'react'

export default function MovieGallery(props) {
  return (
    <div>
    <div className="movie">
        <div >
            <img src={props.img}></img>
            
        </div>
       
        <table>
            <tr>
                <th>Name</th>
                <td>{props.Name}</td>
            </tr>
            <tr>
                <th>Director</th>
                <td>{props.Director}</td>
            </tr>
            <tr>
                <th>Music</th>
                <td>{props.Music }</td>
            </tr>
            <tr>
                <th>Starring</th>
                <td>{props.Starring}</td>
            </tr>
            <tr>
                <th>Industry</th>
                <td>{props.Industry}</td>
            </tr>
        </table> <br></br>
        <audio src={props.audio} type={props.audio/props.mp3} controls></audio>
        <audio1 src={props.audio1} type={props.audio1/props.mp3} controls></audio1>
        <audio2 src={props.audio2} type={props.audio2/props.mp3} controls></audio2> <br></br>
        <video src={props.video} type={props.video/props.mp4} controls></video>
        </div>
        </div>
  )
}
