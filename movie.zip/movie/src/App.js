import logo from "./logo.svg";
import "./App.css";
import MovieGallery from "./components/MovieGallery";

function App() {
  return (
    <div>
      <div>
        <h1>MOVIE GALLERY</h1>
      </div>
      <div className="container">
        <MovieGallery
          a="https://en.wikipedia.org/wiki/Ala_Vaikunthapurramuloo"
          img="https://upload.wikimedia.org/wikipedia/en/2/28/Ala_Vaikunthapurramuloo.jpeg"
          Name="Ala Vaikuntapuram lo"
          Director="Thrivikram Srinivas"
          Music="S.S.Thaman"
          Starring="Allu Arjun,
      Pooja Hegde"
          Industry="Tollywood"
          audio="https://services.brninfotech.com/tws/media2/songs/Ala Vaikuntapuram lo/01 - Samajavaragamana.mp3"
          audio1="https://services.brninfotech.com/tws/media2/songs/Ala Vaikuntapuram lo/02 - Ramuloo Ramulaa.mp3"
          audio2="https://services.brninfotech.com/tws/media2/songs/Ala Vaikuntapuram lo/03 - OMG Daddy.mp3"
          video="https://services.brninfotech.com/tws/media2/trailers/AlaVaikuntapuramloo.mp4"
        />
        <MovieGallery
          a="https://en.wikipedia.org/wiki/War_(2019_film)"
          img="https://upload.wikimedia.org/wikipedia/en/6/6f/War_official_poster.jpg"
          Name="WAR"
          Director="Siddharth Anand"
          Music="Ankit Balhara"
          Starring="	Hrithik Roshan
       Tiger Shroff
       Vaani Kapoor"
          Industry="Bollywood"
          audio="https://services.brninfotech.com/tws/media2/songs/war/jai jai.mp3"
          audio1="https://services.brninfotech.com/tws/media2/songs/war/jai jai.mp3"
          audio2="https://services.brninfotech.com/tws/media2/songs/war/jai jai.mp3" 
          video="https://services.brninfotech.com/tws/media2/trailers/war.mp4"
        />
        <MovieGallery
          a="https://en.wikipedia.org/wiki/The_Zoya_Factor_(film)"
          img="https://upload.wikimedia.org/wikipedia/en/1/1e/The_Zoya_Factor_poster.jpg"
          Name="The Zoya Factor"
          Director="The Zoya Factor"
          Music="Shankar–Ehsaan–Loy"
          Starring="	Dulquer Salmaan
           Sonam Kapoor"
          Industry="Bollywood"
          audio="https://services.brninfotech.com/tws/media2/songs/The Zoya Factor/Lucky Charm.mp3"
          audio1="https://services.brninfotech.com/tws/media2/songs/The Zoya Factor/Lucky Charm.mp3"
          audio2="https://services.brninfotech.com/tws/media2/songs/The Zoya Factor/Lucky Charm.mp3"
          video="https://services.brninfotech.com/tws/media2/trailers/zoyaFactor.mp4"
        />

        <MovieGallery
          a="https://en.wikipedia.org/wiki/Pailwaan"
          img="https://upload.wikimedia.org/wikipedia/en/5/50/Pailwaan_poster.jpg"
          Name="Pehlwaan"
          Director="	S. Krishna"
          Music="Arjun Janya"
          Starring="	Sudeep
Suniel Shetty
Aakanksha Singh"
          Industry="Sandalwood"
          audio="https://services.brninfotech.com/tws/media2/songs/Pahalwan/01 - Vachaadayyo Pahalwan (Theme Song).mp3"
          // audio1="https://services.brninfotech.com/tws/media2/songs/Pahalwan/07 - Prema Kaalam.mp3"
          // audio2="https://services.brninfotech.com/tws/media2/songs/Pahalwan/03 - Jai Ho Pahalwan.mp3"
          video="https://services.brninfotech.com/tws/media2/trailers/Pehlwaan.mp4"
        />

        <MovieGallery
          a="https://en.wikipedia.org/wiki/Jersey_(2019_film)"
          img="https://upload.wikimedia.org/wikipedia/en/7/7f/Jersey_poster.jpg"
          Name="Jersey"
          Director="Gowtam Tinnanuri"
          Music="Anirudh Ravichander"
          Starring="	Nani
Shraddha Srinath	"
          Industry="Tollywood"
          audio="https://services.brninfotech.com/tws/media2/songs/JERSEY/02 - Spirit Of Jersey.mp3"
          // audio1="https://services.brninfotech.com/tws/media2/songs/JERSEY/03 - Padhe Padhe.mp3"
          // audio2="https://services.brninfotech.com/tws/media2/songs/JERSEY/01 - Adhento Gaani Vunnapaatuga.mp3"
          video="https://services.brninfotech.com/tws/media2/trailers/JERSEY.mp4"
        />
        <MovieGallery
          a="https://en.wikipedia.org/wiki/Saaho"
          img="https://upload.wikimedia.org/wikipedia/en/6/6b/Saaho_poster.jpg"
          Name="Saaho"
          Director="Sujeeth"
          Music="Ghibran"
          Starring="Prabhas
          Shraddha Kapoor"
          Industry="Tollywood"
           audio="https://services.brninfotech.com/tws/media2/songs/Saaho/03 - Bad Boy.mp3"
          // audio1="https://services.brninfotech.com/tws/media2/songs/Saaho/02 - Ye Chota Nuvvunna.mp3"
          // audio2="https://services.brninfotech.com/tws/media2/songs/Saaho/05 - Saaho Bang.mp3"
          video="https://services.brninfotech.com/tws/media2/trailers/saaho.mp4"
        />
      </div>
    </div>
  );
}

export default App;
